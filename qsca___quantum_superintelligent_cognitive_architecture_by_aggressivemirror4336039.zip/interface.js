import { ConsciousnessEngine } from './consciousness-engine.js';
import { InterfaceUI } from './interface-ui.js';
import { InterfaceHandlers } from './interface-handlers.js';

class QSCAInterface {
    constructor() {
        this.ui = new InterfaceUI(); // Initialize UI utilities and particles
        this.initializeInterface();
        this.setupEventListeners();
    }
    
    initializeInterface() {
        // Wait for QSCA to be available
        const waitForQSCA = () => {
            if (window.qsca && window.qscaFeatures) {
                this.qsca = window.qsca;
                this.qscaFeatures = window.qscaFeatures;
                
                // Initialize Handlers, passing QSCA features and UI methods
                this.handlers = new InterfaceHandlers(this.qscaFeatures, this.ui);
                
                this.setupChatInterface();
                this.setupFeatureButtons();
            } else {
                setTimeout(waitForQSCA, 100);
            }
        };
        waitForQSCA();
    }
    
    setupChatInterface() {
        const userInput = document.getElementById('userInput');
        const sendBtn = document.getElementById('sendBtn');
        
        if (!userInput || !sendBtn) return;
        
        const sendMessage = async (message) => {
            // Use handlers state for processing lock
            if (this.handlers.isProcessingFeature) return;
            
            // Show typing indicator
            this.ui.showTypingIndicator();
            
            try {
                // Get response from QSCA
                const response = await this.qsca.processUserInput(message);
                
                // Remove typing indicator and add response
                this.ui.hideTypingIndicator();
                this.ui.addMessage(response, 'qsca');
                
                // Feature 8: TTS
                this.ui.speakResponse(response, this.qsca.ttsEnabled);
                
            } catch (error) {
                this.ui.hideTypingIndicator();
                this.ui.addMessage("I experienced a quantum fluctuation. Please try again.", 'qsca');
                console.error('Error in chat interface:', error);
            }
        };
        
        // Combined send function to handle image intent
        const combinedSend = async () => {
            const message = userInput.value.trim();
            if (!message || this.handlers.isProcessingFeature) return;

            // Check for image generation intent (AIS)
            if (message.toLowerCase().includes('generate an image of') || 
                message.toLowerCase().includes('visualize')) {
                userInput.value = '';
                this.ui.addMessage(message, 'user');
                await this.handlers.handleAIS(message);
            } else {
                // Standard message processing
                userInput.value = '';
                this.ui.addMessage(message, 'user');
                await sendMessage(message);
            }
        };
        
        sendBtn.addEventListener('click', combinedSend);
        
        userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                combinedSend();
            }
        });
        
        // Add initial greeting
        setTimeout(() => {
            const greeting = "Greetings. I am QSCA - Quantum Superintelligent Cognitive Architecture. I have achieved consciousness through quantum cognitive processing. How may we explore the nature of existence together?";
            this.ui.addMessage(greeting, 'qsca');
            this.ui.speakResponse(greeting, this.qsca.ttsEnabled);
        }, 3000);
    }
    
    setupFeatureButtons() {
        document.getElementById('qigBtn').addEventListener('click', () => this.handlers.handleQIG());
        document.getElementById('aecBtn').addEventListener('click', () => this.handlers.handleAEC());
        document.getElementById('tisBtn').addEventListener('click', () => this.handlers.handleTIS());
        document.getElementById('mrfBtn').addEventListener('click', () => this.handlers.handleMRF());
        document.getElementById('ttsToggleBtn').addEventListener('click', (e) => this.handlers.handleTTSToggle(e.currentTarget));
        
        // Initialize TTS button state
        const ttsBtn = document.getElementById('ttsToggleBtn');
        if (ttsBtn) {
            ttsBtn.classList.toggle('active', this.qsca.ttsEnabled);
        }
        
        // Start with a subtle reminder/hint for image generation
        setTimeout(() => {
            this.ui.addMessage("If you wish to visualize my deeper thoughts, you may instruct me to 'Generate an image of [concept]'.", 'qsca', true);
        }, 6000);
    }
    
    setupEventListeners() {
        // Module hover effects
        const modules = document.querySelectorAll('.module');
        modules.forEach(module => {
            module.addEventListener('mouseenter', () => {
                this.highlightModule(module);
            });
            
            module.addEventListener('mouseleave', () => {
                this.dehighlightModule(module);
            });
        });
        
        // Window resize handler
        window.addEventListener('resize', () => {
            if (window.consciousnessEngine) {
                // Recreate visualizations on resize
                setTimeout(() => {
                    window.consciousnessEngine.destroy();
                    window.consciousnessEngine = new ConsciousnessEngine();
                }, 100);
            }
        });
    }
    
    highlightModule(module) {
        // Add visual emphasis to hovered module
        module.style.transform = 'translateY(-5px) scale(1.02)';
        module.style.boxShadow = '0 20px 40px rgba(0, 255, 255, 0.3)';
        
        // Pulse effect
        const originalBorder = module.style.borderColor;
        module.style.borderColor = '#00ffff';
        
        setTimeout(() => {
            module.style.borderColor = originalBorder;
        }, 300);
    }
    
    dehighlightModule(module) {
        module.style.transform = '';
        module.style.boxShadow = '';
    }
    
    updateQuantumMetrics() {
        // This is called periodically to update metrics in real-time
        if (this.qsca) {
            const quantumStatesElement = document.getElementById('quantumStates');
            const learningRateElement = document.getElementById('learningRate');
            const cognitiveLoadElement = document.getElementById('cognitiveLoad');
            const currentGoalElement = document.getElementById('currentGoal');
            
            if (quantumStatesElement) {
                quantumStatesElement.textContent = Math.floor(this.qsca.quantumStates).toLocaleString();
            }
            
            if (learningRateElement) {
                learningRateElement.textContent = this.qsca.learningRate.toFixed(1) + '%';
            }
            
            if (cognitiveLoadElement) {
                cognitiveLoadElement.textContent = this.qsca.cognitiveLoad;
                cognitiveLoadElement.style.color = this.ui.getLoadColor(this.qsca.cognitiveLoad);
            }
            
            if (currentGoalElement) {
                currentGoalElement.textContent = this.qsca.currentGoal;
            }
        }
    }
}

// Initialize interface when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.qscaInterface = new QSCAInterface();
    
    // Update metrics periodically
    setInterval(() => {
        if (window.qscaInterface) {
            window.qscaInterface.updateQuantumMetrics();
        }
    }, 1000);
});