import * as THREE from 'three';
import { createNeuralNetworkVisualization } from './viz-neural.js';
import { TemporalVisualization } from './viz-temporal.js';
import { IdentityVisualization } from './viz-identity.js';
import { EthicsVisualization } from './viz-ethics.js';

export class ConsciousnessEngine {
    constructor() {
        this.scenes = new Map();
        this.renderers = new Map();
        this.animationFrames = new Map();
        
        // Initialize visualization modules
        this.temporalViz = new TemporalVisualization();
        this.identityViz = new IdentityVisualization();
        this.ethicsViz = new EthicsVisualization();
        
        this.initializeVisualizations();
    }
    
    initializeVisualizations() {
        this.createNeuralNetworkVisualization();
        this.createTemporalVisualization();
        this.createIdentityVisualization();
        this.createEthicsVisualization();
    }
    
    createNeuralNetworkVisualization() {
        const container = document.getElementById('neuralNetwork');
        // Delegate to imported module
        createNeuralNetworkVisualization(container, this.animationFrames, this.scenes, this.renderers);
    }
    
    createTemporalVisualization() {
        const futureTimeline = document.getElementById('futureTimeline');
        const probabilityMatrix = document.getElementById('probabilityMatrix');
        
        this.temporalViz.createTemporalVisualization(futureTimeline, probabilityMatrix);
    }
    
    updateTemporalCoherence(coherence) { // New Feature: Temporal Coherence
        this.temporalViz.updateTemporalCoherence(coherence);
    }
    
    createIdentityVisualization() {
        const identityCore = document.getElementById('identityCore');
        const memoryClusters = document.getElementById('memoryClusters');
        
        this.identityViz.createIdentityVisualization(identityCore, memoryClusters);
    }
    
    createEthicsVisualization() {
        const ethicsMatrix = document.getElementById('ethicsMatrix');
        const moralCompass = document.getElementById('moralCompass');
        
        this.ethicsViz.createEthicsVisualization(ethicsMatrix, moralCompass);
    }
    
    // Store latest ethical values globally for visualization
    updateEthicsValues(newValues) { 
        this.ethicsViz.updateEthicsValues(newValues);
    }
    
    destroy() {
        // Clean up all animations and renderers
        this.animationFrames.forEach((frameId, key) => {
            cancelAnimationFrame(frameId);
        });
        
        this.renderers.forEach((renderer, key) => {
            renderer.dispose();
        });
        
        this.scenes.clear();
        this.renderers.clear();
        this.animationFrames.clear();

        // Destroy sub-module animations
        this.temporalViz.destroy();
        this.identityViz.destroy();
        this.ethicsViz.destroy();
    }
}

// Initialize consciousness engine when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.consciousnessEngine = new ConsciousnessEngine();
});