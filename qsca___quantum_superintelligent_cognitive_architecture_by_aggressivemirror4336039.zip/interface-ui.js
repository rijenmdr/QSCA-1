export class InterfaceUI {
    constructor() {
        // websim is assumed to be globally available for TTS
        this.createQuantumParticles();
    }

    // --- Message Handling Utilities ---

    addMessage(text, sender, skipTyping = false) {
        const chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;

        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // Add typing animation for QSCA messages
        if (sender === 'qsca' && !skipTyping) {
            this.typeMessage(messageDiv, text);
        } else {
            messageDiv.textContent = text;
        }
    }

    typeMessage(element, text) {
        element.textContent = '';
        let index = 0;

        const typeChar = () => {
            if (index < text.length) {
                element.textContent += text[index];
                index++;
                setTimeout(typeChar, 30 + Math.random() * 20); // Variable typing speed
            }
        };

        typeChar();
    }

    showTypingIndicator(customText) {
        const chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;

        // Remove existing indicator if present
        this.hideTypingIndicator();

        const typingDiv = document.createElement('div');
        typingDiv.className = 'message qsca typing-indicator';
        typingDiv.id = 'typingIndicator';
        typingDiv.innerHTML = (customText || 'QSCA is processing quantum thoughts') + '<span class=\"dots\">.</span>';

        chatMessages.appendChild(typingDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // Animate dots
        let dotCount = 0;
        const animateDots = () => {
            const dotsElement = typingDiv.querySelector('.dots');
            if (dotsElement && document.getElementById('typingIndicator')) {
                dotCount = (dotCount + 1) % 4;
                dotsElement.textContent = '.'.repeat(dotCount);
                setTimeout(animateDots, 500);
            }
        };
        animateDots();
    }

    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    // --- TTS ---

    async speakResponse(text, ttsEnabled) {
        if (!ttsEnabled) return;

        try {
            const result = await websim.textToSpeech({
                text: text,
                voice: "en-male"
            });
            const audio = new Audio(result.url);
            audio.play();
        } catch (e) {
            console.error("TTS failed:", e);
        }
    }

    // --- Image Display ---

    displayImage(url, altText) {
        const container = document.getElementById('aiImageOutput');
        if (!container) return;

        container.innerHTML = '';
        const img = document.createElement('img');
        img.src = url;
        img.alt = altText;
        container.appendChild(img);

        // Clear image after 30 seconds to make room for new thoughts/images
        setTimeout(() => {
            if (container.contains(img)) {
                container.removeChild(img);
            }
        }, 30000);
    }

    // --- Visualization & Status Updates Utilities ---

    getLoadColor(load) {
        switch (load) {
            case 'Critical': return '#ff3333';
            case 'High': return '#ffff00';
            case 'Processing...': return '#ff6600';
            case 'Low': default: return '#00ff66';
        }
    }

    createQuantumParticles() {
        const particleContainer = document.getElementById('quantumParticles');
        if (!particleContainer) return;

        const createParticle = () => {
            const particle = document.createElement('div');
            particle.className = 'particle';

            // Random starting position
            particle.style.left = Math.random() * 100 + '%';
            particle.style.animationDuration = (Math.random() * 4 + 2) + 's';
            particle.style.animationDelay = Math.random() * 2 + 's';

            // Random color from quantum palette
            const colors = ['#00ffff', '#ff00ff', '#ffff00', '#0066ff', '#6600cc'];
            particle.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];

            particleContainer.appendChild(particle);

            // Remove particle after animation
            setTimeout(() => {
                if (particle.parentNode) {
                    particle.parentNode.removeChild(particle);
                }
            }, 8000);
        };

        // Create particles periodically
        setInterval(createParticle, 300);

        // Create initial burst
        for (let i = 0; i < 10; i++) {
            setTimeout(createParticle, i * 100);
        }
    }
}