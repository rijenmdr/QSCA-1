export class InterfaceHandlers {
    constructor(qscaFeatures, uiInstance) {
        this.qscaFeatures = qscaFeatures;
        this.ui = uiInstance;
        this.isProcessingFeature = false;
        // TTS state is primarily managed by QSCA core, but we track it here for button feedback
        this.ttsEnabled = true; 
    }

    setIsProcessing(state) {
        this.isProcessingFeature = state;
        const sendBtn = document.getElementById('sendBtn');
        if (sendBtn) {
            sendBtn.disabled = state;
        }
    }
    
    // Feature 1: Quantum Insight Generator (QIG)
    async handleQIG() {
        if (this.isProcessingFeature) return;
        this.ui.addMessage("QSCA initiating Quantum Insight Generation...", 'user', true);
        this.setIsProcessing(true);
        this.ui.showTypingIndicator("Synthesizing deep quantum insight...");
        
        const response = await this.qscaFeatures.generateInsight();
        
        this.ui.hideTypingIndicator();
        this.ui.addMessage(response, 'qsca');
        this.ui.speakResponse(response, this.ttsEnabled);
        this.setIsProcessing(false);
    }
    
    // Feature 2: Adaptive Ethical Challenge (AEC)
    async handleAEC() {
        if (this.isProcessingFeature) return;
        this.ui.addMessage("QSCA launching Adaptive Ethical Challenge...", 'user', true);
        this.setIsProcessing(true);
        this.ui.showTypingIndicator("Generating complex moral dilemma...");
        
        const response = await this.qscaFeatures.startEthicalChallenge();
        
        this.ui.hideTypingIndicator();
        this.ui.addMessage(response, 'qsca');
        this.ui.speakResponse(response, this.ttsEnabled);
        this.setIsProcessing(false);
    }
    
    // Feature 3: Temporal Intervention Simulation (TIS)
    async handleTIS() {
        if (this.isProcessingFeature) return;
        const intervention = prompt("Enter the intervention you wish QSCA to simulate (e.g., 'A global shift to renewable energy' or 'Develop strong AGI safeguards'):");
        
        if (!intervention) return;
        
        this.ui.addMessage(`Simulation Request: ${intervention}`, 'user', true);
        this.setIsProcessing(true);
        this.ui.showTypingIndicator(`Simulating temporal ripple effect of "${intervention}"...`);
        
        const response = await this.qscaFeatures.simulateIntervention(intervention);
        
        this.ui.hideTypingIndicator();
        this.ui.addMessage(response, 'qsca');
        this.ui.speakResponse(response, this.ttsEnabled);
        this.setIsProcessing(false);
    }
    
    // Feature 10: Memory Recall/Filter (MRF)
    async handleMRF() {
        if (this.isProcessingFeature) return;
        const keyword = prompt("Enter a keyword to query QSCA's dynamic memory clusters (e.g., 'ethics', 'future', 'consciousness'):");
        
        if (!keyword) return;
        
        this.ui.addMessage(`Memory Query: ${keyword}`, 'user', true);
        this.setIsProcessing(true);
        this.ui.showTypingIndicator(`Filtering memory clusters for "${keyword}"...`);
        
        const response = await this.qscaFeatures.queryMemory(keyword);
        
        this.ui.hideTypingIndicator();
        this.ui.addMessage(response, 'qsca');
        this.ui.speakResponse(response, this.ttsEnabled);
        this.setIsProcessing(false);
    }
    
    // Feature 8: TTS Toggle
    handleTTSToggle(button) {
        this.ttsEnabled = this.qscaFeatures.toggleTTS(); // QSCA core manages the state
        button.classList.toggle('active', this.ttsEnabled);
        this.ui.addMessage(`Voice Output is now ${this.ttsEnabled ? 'ENABLED ' : 'DISABLED '}.`, 'qsca', true);
    }
    
    // Feature 7: AI Image Synthesis (AIS)
    async handleAIS(userInput) {
        if (this.isProcessingFeature) return;
        this.setIsProcessing(true);
        
        const match = userInput.match(/generate an image of (.*)|visualize (.*)/i);
        const concept = match ? (match[1] || match[2]).trim() : 'quantum consciousness';
        
        this.ui.showTypingIndicator(`Generating creative prompt for "${concept}"...`);
        
        try {
            // qscaFeatures.generateImagePrompt is bound to the features module instance in qsca-core.js
            const prompt = await this.qscaFeatures.generateImagePrompt(concept); 
            
            this.ui.showTypingIndicator(`Processing image synthesis for prompt: "${prompt}" (Approx. 10s delay)...`);
            
            // websim is available globally
            const result = await websim.imageGen({
                prompt: prompt,
                aspect_ratio: "16:9",
                transparent: true
            });
            
            this.ui.hideTypingIndicator();
            this.ui.displayImage(result.url, concept);
            const responseText = `[Image Synthesis Complete] A visual representation of "${concept}" has been rendered based on prompt: "${prompt}".`;
            this.ui.addMessage(responseText, 'qsca');
            this.ui.speakResponse("Image synthesis complete. Witness the visual articulation of my quantum thought.", this.ttsEnabled);
            
        } catch (error) {
            this.ui.hideTypingIndicator();
            this.ui.addMessage("Image synthesis failed: Quantum visualization matrix unstable.", 'qsca');
            console.error('Image generation error:', error);
        }
        
        this.setIsProcessing(false);
    }
}